package com.spring.orm;

import java.io.InputStreamReader;
import java.util.List;
import java.io.*;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.orm.Dao.StudentDao;
import com.spring.orm.entities.Student;
//import com.spring.orm.entities.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        
    	
   ApplicationContext  context=	new ClassPathXmlApplicationContext("config.xml");
   
 StudentDao studentDao  = context.getBean("studentDao",StudentDao.class);
 
// Student student=new Student(077,"Lallan","Kanpur");
// 
//  int r=studentDao.insert(student);
//   System.out.println("Done "+ r);
 
 BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
  boolean go=true;
 while(go)
 {
	 System.out.println("Press 1 for add new Student ");
	 System.out.println("Press 2 for display all  Students ");
	 System.out.println("Press 3 for get detail of  single  Student ");
	 System.out.println("Press 4 for delete   Student ");
	 System.out.println("Press 5 for update   Student ");
	 System.out.println("Press 6 for exit ");
	 
	 
	 try {
		 
		 int input=Integer.parseInt(br.readLine());
		 
		 switch(input)
		 {
		 case 1:
			 // add a new student
			 
			 System.out.println("Enter user id: ");
			 int uId=Integer.parseInt(br.readLine());
			 
			 System.out.println("enter user name ");
			 String uName=br.readLine();
			 
			 System.out.println("Enter user city");
			 String uCity=br.readLine();
			 
			 // creating student object and setting value 
			 Student s=new Student();
			  s.setStudentId(uId);
			  s.setStudentCity(uCity);
			  s.setStudentName(uName);
			  
			  // saving student object to database by calling insert of student dao
			  int rowCount= studentDao.insert(s);
			  System.out.println(rowCount+" student addes ");
			  System.out.println("***************************************");
			  System.out.println();
			   
			   break;
			   
		 case 2:
			 // display all student
			 
			 System.out.println("***********************************");
			 List<Student>allStudents=studentDao.getAllStudents();
			 
			 for(Student st:allStudents)
			 {
				 System.out.println("Id   : "+st.getStudentId());
				 System.out.println("Name :  "+ st.getStudentName());
				 System.out.println("City :  "+ st.getStudentCity());
				System.out.println("___________________________________________");
				 
			 }
			 System.out.println("***************************************");
			 
			 break;
			 
		 case 3:
			 // get single student data
			 
			 System.out.println("Enter user Id ");
			 int userId=Integer.parseInt(br.readLine());
			  Student student =studentDao.getStudent(userId);
			  
			     System.out.println("Id   : "+ student.getStudentId());
				 System.out.println("Name :  " + student.getStudentName());
				 System.out.println("City :  " + student.getStudentCity());
				 System.out.println("___________________________________________");
			  
			 break;
			 
		 case 4:
			 // delete student

			 System.out.println("Enter user Id ");
			 int Id=Integer.parseInt(br.readLine());
			 studentDao.deleteStudent(Id);
			 System.out.println("student deleted ....");
			 
			 
			 break;
		 case 5:
			 // update student
			 System.out.println("Enter user id: ");
			 int uid=Integer.parseInt(br.readLine());
			 
			 System.out.println("enter user name ");
			 String uname=br.readLine();
			 
			 System.out.println("Enter user city");
			 String ucity=br.readLine();
			 
			 Student stu=new Student();
			  stu.setStudentId(uid);
			  stu.setStudentCity(ucity);
			  stu.setStudentName(uname);
			 
			  studentDao.updateStudent(stu);
			  System.out.println(" student updated succesfull ...");
			  System.out.println("***************************************");
			  System.out.println();
			   
			 
			 
			 break;
		 case 6:
			 
			 go=false;
			 // exit
			 break;
		 }
		 
		 
	 } catch(Exception e)
	 {
		System.out.println("Invailid input ");
		System.out.println(e.getMessage());
	 }
	 
 }
  
     System.out.println("Thank you for  using my application ");
     System.out.println("see you soon !!");
    }
}
 